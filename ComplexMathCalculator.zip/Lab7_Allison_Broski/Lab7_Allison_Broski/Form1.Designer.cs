﻿namespace Lab7_Allison_Broski
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpInput = new System.Windows.Forms.GroupBox();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.lblEqual = new System.Windows.Forms.Label();
            this.lblOperator = new System.Windows.Forms.Label();
            this.txtImaginary2 = new System.Windows.Forms.TextBox();
            this.txtNormal2 = new System.Windows.Forms.TextBox();
            this.txtImaginary1 = new System.Windows.Forms.TextBox();
            this.txtNormal1 = new System.Windows.Forms.TextBox();
            this.lblII = new System.Windows.Forms.Label();
            this.lblI = new System.Windows.Forms.Label();
            this.lblPlusPlus = new System.Windows.Forms.Label();
            this.lblPlus = new System.Windows.Forms.Label();
            this.lblParenthes = new System.Windows.Forms.Label();
            this.lblParenthesis = new System.Windows.Forms.Label();
            this.lblParenthe = new System.Windows.Forms.Label();
            this.lblParenth = new System.Windows.Forms.Label();
            this.grpUser = new System.Windows.Forms.GroupBox();
            this.btnDivideUser = new System.Windows.Forms.Button();
            this.btnMultiplyUser = new System.Windows.Forms.Button();
            this.btnSubtractUser = new System.Windows.Forms.Button();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.grpFile = new System.Windows.Forms.GroupBox();
            this.btnDivideFile = new System.Windows.Forms.Button();
            this.btnMultiplyFile = new System.Windows.Forms.Button();
            this.btnSubtractFile = new System.Windows.Forms.Button();
            this.btnAddFile = new System.Windows.Forms.Button();
            this.lstResults = new System.Windows.Forms.ListBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpInput.SuspendLayout();
            this.grpUser.SuspendLayout();
            this.grpFile.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpInput
            // 
            this.grpInput.Controls.Add(this.lblAnswer);
            this.grpInput.Controls.Add(this.lblEqual);
            this.grpInput.Controls.Add(this.lblOperator);
            this.grpInput.Controls.Add(this.txtImaginary2);
            this.grpInput.Controls.Add(this.txtNormal2);
            this.grpInput.Controls.Add(this.txtImaginary1);
            this.grpInput.Controls.Add(this.txtNormal1);
            this.grpInput.Controls.Add(this.lblII);
            this.grpInput.Controls.Add(this.lblI);
            this.grpInput.Controls.Add(this.lblPlusPlus);
            this.grpInput.Controls.Add(this.lblPlus);
            this.grpInput.Controls.Add(this.lblParenthes);
            this.grpInput.Controls.Add(this.lblParenthesis);
            this.grpInput.Controls.Add(this.lblParenthe);
            this.grpInput.Controls.Add(this.lblParenth);
            this.grpInput.Location = new System.Drawing.Point(12, 12);
            this.grpInput.Name = "grpInput";
            this.grpInput.Size = new System.Drawing.Size(707, 100);
            this.grpInput.TabIndex = 0;
            this.grpInput.TabStop = false;
            this.grpInput.Text = "Place Complex Numbers Here";
            // 
            // lblAnswer
            // 
            this.lblAnswer.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblAnswer.Location = new System.Drawing.Point(489, 43);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(135, 24);
            this.lblAnswer.TabIndex = 16;
            // 
            // lblEqual
            // 
            this.lblEqual.AutoSize = true;
            this.lblEqual.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEqual.Location = new System.Drawing.Point(459, 42);
            this.lblEqual.Name = "lblEqual";
            this.lblEqual.Size = new System.Drawing.Size(24, 25);
            this.lblEqual.TabIndex = 15;
            this.lblEqual.Text = "=";
            // 
            // lblOperator
            // 
            this.lblOperator.BackColor = System.Drawing.Color.Gainsboro;
            this.lblOperator.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperator.Location = new System.Drawing.Point(215, 42);
            this.lblOperator.Name = "lblOperator";
            this.lblOperator.Size = new System.Drawing.Size(40, 23);
            this.lblOperator.TabIndex = 14;
            this.lblOperator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtImaginary2
            // 
            this.txtImaginary2.Location = new System.Drawing.Point(361, 45);
            this.txtImaginary2.Name = "txtImaginary2";
            this.txtImaginary2.Size = new System.Drawing.Size(54, 20);
            this.txtImaginary2.TabIndex = 13;
            // 
            // txtNormal2
            // 
            this.txtNormal2.Location = new System.Drawing.Point(280, 45);
            this.txtNormal2.Name = "txtNormal2";
            this.txtNormal2.Size = new System.Drawing.Size(54, 20);
            this.txtNormal2.TabIndex = 12;
            // 
            // txtImaginary1
            // 
            this.txtImaginary1.Location = new System.Drawing.Point(124, 45);
            this.txtImaginary1.Name = "txtImaginary1";
            this.txtImaginary1.Size = new System.Drawing.Size(54, 20);
            this.txtImaginary1.TabIndex = 11;
            // 
            // txtNormal1
            // 
            this.txtNormal1.Location = new System.Drawing.Point(35, 45);
            this.txtNormal1.Name = "txtNormal1";
            this.txtNormal1.Size = new System.Drawing.Size(54, 20);
            this.txtNormal1.TabIndex = 10;
            // 
            // lblII
            // 
            this.lblII.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblII.Location = new System.Drawing.Point(421, 39);
            this.lblII.Name = "lblII";
            this.lblII.Size = new System.Drawing.Size(23, 30);
            this.lblII.TabIndex = 9;
            this.lblII.Text = "i";
            // 
            // lblI
            // 
            this.lblI.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblI.Location = new System.Drawing.Point(184, 39);
            this.lblI.Name = "lblI";
            this.lblI.Size = new System.Drawing.Size(23, 30);
            this.lblI.TabIndex = 8;
            this.lblI.Text = "i";
            // 
            // lblPlusPlus
            // 
            this.lblPlusPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlusPlus.Location = new System.Drawing.Point(332, 39);
            this.lblPlusPlus.Name = "lblPlusPlus";
            this.lblPlusPlus.Size = new System.Drawing.Size(23, 30);
            this.lblPlusPlus.TabIndex = 7;
            this.lblPlusPlus.Text = "+";
            // 
            // lblPlus
            // 
            this.lblPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlus.Location = new System.Drawing.Point(95, 39);
            this.lblPlus.Name = "lblPlus";
            this.lblPlus.Size = new System.Drawing.Size(23, 30);
            this.lblPlus.TabIndex = 6;
            this.lblPlus.Text = "+";
            // 
            // lblParenthes
            // 
            this.lblParenthes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParenthes.Location = new System.Drawing.Point(251, 39);
            this.lblParenthes.Name = "lblParenthes";
            this.lblParenthes.Size = new System.Drawing.Size(23, 30);
            this.lblParenthes.TabIndex = 5;
            this.lblParenthes.Text = "(";
            // 
            // lblParenthesis
            // 
            this.lblParenthesis.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParenthesis.Location = new System.Drawing.Point(440, 39);
            this.lblParenthesis.Name = "lblParenthesis";
            this.lblParenthesis.Size = new System.Drawing.Size(23, 30);
            this.lblParenthesis.TabIndex = 4;
            this.lblParenthesis.Text = ")";
            // 
            // lblParenthe
            // 
            this.lblParenthe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParenthe.Location = new System.Drawing.Point(200, 39);
            this.lblParenthe.Name = "lblParenthe";
            this.lblParenthe.Size = new System.Drawing.Size(23, 30);
            this.lblParenthe.TabIndex = 3;
            this.lblParenthe.Text = ")";
            // 
            // lblParenth
            // 
            this.lblParenth.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParenth.Location = new System.Drawing.Point(17, 39);
            this.lblParenth.Name = "lblParenth";
            this.lblParenth.Size = new System.Drawing.Size(23, 30);
            this.lblParenth.TabIndex = 2;
            this.lblParenth.Text = "(";
            // 
            // grpUser
            // 
            this.grpUser.Controls.Add(this.btnDivideUser);
            this.grpUser.Controls.Add(this.btnMultiplyUser);
            this.grpUser.Controls.Add(this.btnSubtractUser);
            this.grpUser.Controls.Add(this.btnAddUser);
            this.grpUser.Location = new System.Drawing.Point(12, 134);
            this.grpUser.Name = "grpUser";
            this.grpUser.Size = new System.Drawing.Size(334, 76);
            this.grpUser.TabIndex = 1;
            this.grpUser.TabStop = false;
            this.grpUser.Text = "Compute Values from User Input";
            // 
            // btnDivideUser
            // 
            this.btnDivideUser.BackColor = System.Drawing.Color.Orange;
            this.btnDivideUser.Location = new System.Drawing.Point(249, 28);
            this.btnDivideUser.Name = "btnDivideUser";
            this.btnDivideUser.Size = new System.Drawing.Size(75, 23);
            this.btnDivideUser.TabIndex = 5;
            this.btnDivideUser.Text = "Divide";
            this.btnDivideUser.UseVisualStyleBackColor = false;
            this.btnDivideUser.Click += new System.EventHandler(this.btnDivideUser_Click);
            // 
            // btnMultiplyUser
            // 
            this.btnMultiplyUser.BackColor = System.Drawing.Color.Orange;
            this.btnMultiplyUser.Location = new System.Drawing.Point(168, 28);
            this.btnMultiplyUser.Name = "btnMultiplyUser";
            this.btnMultiplyUser.Size = new System.Drawing.Size(75, 23);
            this.btnMultiplyUser.TabIndex = 4;
            this.btnMultiplyUser.Text = "Multiply";
            this.btnMultiplyUser.UseVisualStyleBackColor = false;
            this.btnMultiplyUser.Click += new System.EventHandler(this.btnMultiplyUser_Click);
            // 
            // btnSubtractUser
            // 
            this.btnSubtractUser.BackColor = System.Drawing.Color.Orange;
            this.btnSubtractUser.Location = new System.Drawing.Point(87, 28);
            this.btnSubtractUser.Name = "btnSubtractUser";
            this.btnSubtractUser.Size = new System.Drawing.Size(75, 23);
            this.btnSubtractUser.TabIndex = 3;
            this.btnSubtractUser.Text = "Subtract";
            this.btnSubtractUser.UseVisualStyleBackColor = false;
            this.btnSubtractUser.Click += new System.EventHandler(this.btnSubtractUser_Click);
            // 
            // btnAddUser
            // 
            this.btnAddUser.BackColor = System.Drawing.Color.Orange;
            this.btnAddUser.Location = new System.Drawing.Point(6, 28);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(75, 23);
            this.btnAddUser.TabIndex = 2;
            this.btnAddUser.Text = "Add";
            this.btnAddUser.UseVisualStyleBackColor = false;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // grpFile
            // 
            this.grpFile.Controls.Add(this.btnDivideFile);
            this.grpFile.Controls.Add(this.btnMultiplyFile);
            this.grpFile.Controls.Add(this.btnSubtractFile);
            this.grpFile.Controls.Add(this.btnAddFile);
            this.grpFile.Location = new System.Drawing.Point(12, 226);
            this.grpFile.Name = "grpFile";
            this.grpFile.Size = new System.Drawing.Size(334, 89);
            this.grpFile.TabIndex = 1;
            this.grpFile.TabStop = false;
            this.grpFile.Text = "Compute Values from File Input";
            // 
            // btnDivideFile
            // 
            this.btnDivideFile.BackColor = System.Drawing.Color.Turquoise;
            this.btnDivideFile.Location = new System.Drawing.Point(249, 32);
            this.btnDivideFile.Name = "btnDivideFile";
            this.btnDivideFile.Size = new System.Drawing.Size(75, 23);
            this.btnDivideFile.TabIndex = 3;
            this.btnDivideFile.Text = "Divide";
            this.btnDivideFile.UseVisualStyleBackColor = false;
            this.btnDivideFile.Click += new System.EventHandler(this.btnDivideFile_Click);
            // 
            // btnMultiplyFile
            // 
            this.btnMultiplyFile.BackColor = System.Drawing.Color.Turquoise;
            this.btnMultiplyFile.Location = new System.Drawing.Point(168, 32);
            this.btnMultiplyFile.Name = "btnMultiplyFile";
            this.btnMultiplyFile.Size = new System.Drawing.Size(75, 23);
            this.btnMultiplyFile.TabIndex = 2;
            this.btnMultiplyFile.Text = "Multiply";
            this.btnMultiplyFile.UseVisualStyleBackColor = false;
            this.btnMultiplyFile.Click += new System.EventHandler(this.btnMultiplyFile_Click);
            // 
            // btnSubtractFile
            // 
            this.btnSubtractFile.BackColor = System.Drawing.Color.Turquoise;
            this.btnSubtractFile.Location = new System.Drawing.Point(87, 32);
            this.btnSubtractFile.Name = "btnSubtractFile";
            this.btnSubtractFile.Size = new System.Drawing.Size(75, 23);
            this.btnSubtractFile.TabIndex = 1;
            this.btnSubtractFile.Text = "Subtract";
            this.btnSubtractFile.UseVisualStyleBackColor = false;
            this.btnSubtractFile.Click += new System.EventHandler(this.btnSubtractFile_Click);
            // 
            // btnAddFile
            // 
            this.btnAddFile.BackColor = System.Drawing.Color.Turquoise;
            this.btnAddFile.Location = new System.Drawing.Point(6, 32);
            this.btnAddFile.Name = "btnAddFile";
            this.btnAddFile.Size = new System.Drawing.Size(75, 23);
            this.btnAddFile.TabIndex = 0;
            this.btnAddFile.Text = "Add";
            this.btnAddFile.UseVisualStyleBackColor = false;
            this.btnAddFile.Click += new System.EventHandler(this.btnAddFile_Click);
            // 
            // lstResults
            // 
            this.lstResults.FormattingEnabled = true;
            this.lstResults.Location = new System.Drawing.Point(352, 233);
            this.lstResults.Name = "lstResults";
            this.lstResults.Size = new System.Drawing.Size(355, 82);
            this.lstResults.TabIndex = 2;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.LightCoral;
            this.btnExit.Location = new System.Drawing.Point(12, 321);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(108, 33);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 366);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lstResults);
            this.Controls.Add(this.grpUser);
            this.Controls.Add(this.grpFile);
            this.Controls.Add(this.grpInput);
            this.Name = "frmMain";
            this.Text = "Calculations and Such";
            this.grpInput.ResumeLayout(false);
            this.grpInput.PerformLayout();
            this.grpUser.ResumeLayout(false);
            this.grpFile.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpInput;
        private System.Windows.Forms.GroupBox grpUser;
        private System.Windows.Forms.GroupBox grpFile;
        private System.Windows.Forms.Button btnDivideUser;
        private System.Windows.Forms.Button btnMultiplyUser;
        private System.Windows.Forms.Button btnSubtractUser;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.Button btnDivideFile;
        private System.Windows.Forms.Button btnMultiplyFile;
        private System.Windows.Forms.Button btnSubtractFile;
        private System.Windows.Forms.Button btnAddFile;
        private System.Windows.Forms.Label lblParenth;
        private System.Windows.Forms.Label lblII;
        private System.Windows.Forms.Label lblI;
        private System.Windows.Forms.Label lblPlusPlus;
        private System.Windows.Forms.Label lblPlus;
        private System.Windows.Forms.Label lblParenthes;
        private System.Windows.Forms.Label lblParenthesis;
        private System.Windows.Forms.Label lblParenthe;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Label lblEqual;
        private System.Windows.Forms.Label lblOperator;
        private System.Windows.Forms.TextBox txtImaginary2;
        private System.Windows.Forms.TextBox txtNormal2;
        private System.Windows.Forms.TextBox txtImaginary1;
        private System.Windows.Forms.TextBox txtNormal1;
        private System.Windows.Forms.ListBox lstResults;
        private System.Windows.Forms.Button btnExit;
    }
}

