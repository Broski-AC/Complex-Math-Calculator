﻿/*
‘LAB #7
'Fall 2017
‘Allison Broski
‘I fully understand the following statement. ‘OU PLAGIARISM POLICY
‘All members of the academic community at Oakland are expected to practice and 
uphold ‘standards of academic integrity and honesty. An instructor is expected to 
inform and instruct ‘students about the procedures and standards of research and 
documentation required of students ‘in fulfilling course work. A student is expected
to follow such instructions and be sure the rules ‘and procedures are understood in order
to avoid inadvertent misrepresentation of her/his work. ‘Students must assume that individual
(unaided) work on exams and lab reports and documentation ‘of sources is expected unless
the instructor specifically says that is not necessary.

‘The following definitions are some examples of academic dishonesty:
 ‘Plagiarizing from work of others. Plagiarism is using someone else's work or ideas 
without ‘giving the other person credit; by doing this, a student is, in effect, claiming 
credit for ‘someone else's thinking. Whether the student has read or heard the information 
she/he uses, ‘the student must document the source of information. When dealing with written 
sources,
‘a clear distinction would be made between quotations (which reproduce information from 
‘the source word-for-word within quotation marks) and paraphrases (which digest the ‘source 
information and produce it in the student's own words). Both direct quotations and 
‘paraphrases must be documented. Just because a student rephrases, condenses or selects
‘from another person's work, the ideas are still the other person's, and failure to give
‘credit constitutes misrepresentation of the student's actual work and plagiarism of 
‘another's ideas. Naturally, buying a paper and handing it in as one's own work is ‘plagiarism.
   ‘Cheating on lab reports falsifying data or submitting data not based on student's own work.
*/




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Lab7_Allison_Broski
{
    public partial class frmMain : Form
    {
        int normal1, normal2, imaginary1, imaginary2, u;
        string output;
        
        struct CalculationValues
        //Creating a structor that will hold the values from the text file for calculations within the methods
        {
            public int real1;
            public int imaginary1;

        }

        //Reading the values in from the text file and storing in a string array
        static string[] values = File.ReadAllLines("Input.txt");
        //Generating the size of a new array to store the text file values
        static int size = values.Length; // This gets the length of the document
        CalculationValues[] complexNums = new CalculationValues[size]; //This sets the length of the array complexNums equal to the size of the document

        //Note for self: complexNums is an array that contains the structure CalculationValues. 
        //Note for self 2: We must increment by 2 because u is still technically 0 in that first iteration. It does not change value entirelly when we add one. 
        //Incrementation by 2 results in u = 2, and then we start with a new pair of values
        //Note for self 3: The text file is in bin -> debug under Lab7_Allison file within the main file
        public frmMain()
        {
            InitializeComponent();

        }

        private void btnSubtractUser_Click(object sender, EventArgs e)
        {
            //Takes input from the user and performs a calculation
            int.TryParse(txtNormal1.Text, out normal1);
            int.TryParse(txtNormal2.Text, out normal2);
            int.TryParse(txtImaginary1.Text, out imaginary1);
            int.TryParse(txtImaginary2.Text, out imaginary2);

            if ((normal1 == 0) || (normal2 == 0) || (imaginary1 == 0) || (imaginary2 == 0 ))
            {
                MessageBox.Show("Please Insert a Whole Number");
            }

            lblOperator.Text = " - ";

            output = ComplexMath.MathFunctions.Subtract(normal1, imaginary1, normal2, imaginary2);
            lblAnswer.Text = output;
        }

        private void btnMultiplyUser_Click(object sender, EventArgs e)
        {
            //Takes input from the user and performs a calculation
            int.TryParse(txtNormal1.Text, out normal1);
            int.TryParse(txtNormal2.Text, out normal2);
            int.TryParse(txtImaginary1.Text, out imaginary1);
            int.TryParse(txtImaginary2.Text, out imaginary2);

            if ((normal1 == 0) || (normal2 == 0) || (imaginary1 == 0) || (imaginary2 == 0 ))
            {
                MessageBox.Show("Please Insert a Whole Number");
            }

            lblOperator.Text = " * ";

            output = ComplexMath.MathFunctions.Multiply(normal1, imaginary1, normal2, imaginary2);
            lblAnswer.Text = output;
        }

        private void btnSubtractFile_Click(object sender, EventArgs e)
        {
            lstResults.Items.Clear();

            for (u = 0; u < size - 1; u += 2)
            {
                string[] number = values[u].Split(','); //Takes the first line in the text file and splits it up, putting each value into the string array 'number'
                complexNums[u].real1 = int.Parse(number[0]); // Takes the value in slot 0 of the number array and assigns it to real1 in the structure complexNums
                complexNums[u].imaginary1 = int.Parse(number[1]); //Takes the value in slot 1 of the number array and assigns it to imaginary1 in the structure complexNums
                string[] number1 = values[u + 1].Split(','); //Split the values on the second line and puts it into a new array
                complexNums[u + 1].real1 = int.Parse(number1[0]); // Takes the value in slot 0 of the numbers array and assigns it to real1 in the structure complexNums
                complexNums[u + 1].imaginary1 = int.Parse(number1[1]); // Takes the value in slot 1 of the numbers array and assigns it to imaginary1 in the strucute complexNums

                //Perform the mathematical operation!
                output = ComplexMath.MathFunctions.Subtract(complexNums[u].real1, complexNums[u].imaginary1, complexNums[u + 1].real1, complexNums[u + 1].imaginary1);
                //Display the result in the list box
                lstResults.Items.Add(output);
            }
        }

        private void btnMultiplyFile_Click(object sender, EventArgs e)
        {
            lstResults.Items.Clear();

            for (u = 0; u < size - 1; u += 2)
            {
                string[] number = values[u].Split(','); //Takes the first line in the text file and splits it up, putting each value into the string array 'number'
                complexNums[u].real1 = int.Parse(number[0]); // Takes the value in slot 0 of the number array and assigns it to real1 in the structure complexNums
                complexNums[u].imaginary1 = int.Parse(number[1]); //Takes the value in slot 1 of the number array and assigns it to imaginary1 in the structure complexNums
                string[] number1 = values[u + 1].Split(','); //Split the values on the second line and puts it into a new array
                complexNums[u + 1].real1 = int.Parse(number1[0]); // Takes the value in slot 0 of the numbers array and assigns it to real1 in the structure complexNums
                complexNums[u + 1].imaginary1 = int.Parse(number1[1]); // Takes the value in slot 1 of the numbers array and assigns it to imaginary1 in the strucute complexNums

                //Perform the mathematical operation!
                output = ComplexMath.MathFunctions.Multiply(complexNums[u].real1, complexNums[u].imaginary1, complexNums[u + 1].real1, complexNums[u + 1].imaginary1);
                //Display the result in the list box
                lstResults.Items.Add(output);
            }
        }

        private void btnDivideFile_Click(object sender, EventArgs e)
        {
            lstResults.Items.Clear();

            for (u = 0; u < size - 1; u += 2)
            {
                string[] number = values[u].Split(','); //Takes the first line in the text file and splits it up, putting each value into the string array 'number'
                complexNums[u].real1 = int.Parse(number[0]); // Takes the value in slot 0 of the number array and assigns it to real1 in the structure complexNums
                complexNums[u].imaginary1 = int.Parse(number[1]); //Takes the value in slot 1 of the number array and assigns it to imaginary1 in the structure complexNums
                string[] number1 = values[u + 1].Split(','); //Split the values on the second line and puts it into a new array
                complexNums[u + 1].real1 = int.Parse(number1[0]); // Takes the value in slot 0 of the numbers array and assigns it to real1 in the structure complexNums
                complexNums[u + 1].imaginary1 = int.Parse(number1[1]); // Takes the value in slot 1 of the numbers array and assigns it to imaginary1 in the strucute complexNums

                //Perform the mathematical operation!
                output = ComplexMath.MathFunctions.Divide(complexNums[u].real1, complexNums[u].imaginary1, complexNums[u + 1].real1, complexNums[u + 1].imaginary1);
                //Display the result in the list box
                lstResults.Items.Add(output);
            }
        }

        private void btnAddFile_Click(object sender, EventArgs e)
        {
            lstResults.Items.Clear();

            for (u = 0; u < size - 1 ; u +=2 ) 
            {
                
                string[] number = values[u].Split(','); //Takes the first line in the text file and splits it up, putting each value into the string array 'number'
                complexNums[u].real1 = int.Parse(number[0]); // Takes the value in slot 0 of the number array and assigns it to real1 in the structure complexNums
                complexNums[u].imaginary1 = int.Parse(number[1]); //Takes the value in slot 1 of the number array and assigns it to imaginary1 in the structure complexNums
                string[] number1 = values[u + 1].Split(','); //Split the values on the second line and puts it into a new array
                complexNums[u + 1].real1 = int.Parse(number1[0]); // Takes the value in slot 0 of the numbers array and assigns it to real1 in the structure complexNums
                complexNums[u + 1].imaginary1 = int.Parse(number1[1]); // Takes the value in slot 1 of the numbers array and assigns it to imaginary1 in the strucute complexNums

                //Perform the mathematical operation!
                output = ComplexMath.MathFunctions.Add(complexNums[u].real1, complexNums[u].imaginary1, complexNums[u +1].real1, complexNums[u+1].imaginary1);
                //Display the result in the list box
                lstResults.Items.Add(output);
            }
        }

        private void btnDivideUser_Click(object sender, EventArgs e)
        {
            //Takes input from a user and performs a calculation
            int.TryParse(txtNormal1.Text, out normal1);
            int.TryParse(txtNormal2.Text, out normal2);
            int.TryParse(txtImaginary1.Text, out imaginary1);
            int.TryParse(txtImaginary2.Text, out imaginary2);

            if ((normal1 == 0) || (normal2 == 0) || (imaginary1 == 0) || (imaginary2 == 0 ))
            {
                MessageBox.Show("Please Insert a Whole Number");
            }

            lblOperator.Text = " / ";

            output = ComplexMath.MathFunctions.Divide(normal1, imaginary1, normal2, imaginary2);
            lblAnswer.Text = output;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            //Takes input from a user and performs a calculation
            int.TryParse(txtNormal1.Text, out normal1);
            int.TryParse(txtNormal2.Text, out normal2);
            int.TryParse(txtImaginary1.Text, out imaginary1);
            int.TryParse(txtImaginary2.Text, out imaginary2);

            if ((normal1 == 0) || (normal2 == 0) || (imaginary1 == 0) || (imaginary2 == 0 ))
            {
                MessageBox.Show("Please Insert a Whole Number");
            }

            lblOperator.Text = " + ";

            output = ComplexMath.MathFunctions.Add(normal1, imaginary1, normal2, imaginary2);
            lblAnswer.Text = output;
        }



    }
    }
